package com.example.hrms

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
